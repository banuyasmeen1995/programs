# -*- coding: utf-8 -*-
"""
Created on Fri Sep 17 12:51:50 2021

@author: sharmidha soundararajan
"""
#Program2

word1 = input("Enter the word1: ")
word2 = input("Enter the word2: ")
word3 = input("Enter the word3: ")

print("yyy"+word1+"yyy"+word2+"yyy"+word3)