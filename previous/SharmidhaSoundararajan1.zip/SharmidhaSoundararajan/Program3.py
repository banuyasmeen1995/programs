# -*- coding: utf-8 -*-
"""
Created on Thu Sep 16 11:22:20 2021

@author: sharmidha soundararajan
"""
#Program3
n = eval(input("Enter a value: "))
sum = 0
for i in range(1,n+1):
    sum=sum+i

print("Sum of intergers is:", sum)