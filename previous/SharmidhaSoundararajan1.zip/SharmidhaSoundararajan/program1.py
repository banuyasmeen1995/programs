# -*- coding: utf-8 -*-
"""
Spyder Editor

@author: sharmidha soundararajan

This is a temporary script file.
"""
#Program1

name = input("What is your name? ")
title = input ("What is your title? ")
print("Hello"+ " " + title + " " +name)